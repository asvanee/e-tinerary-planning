import { useCallback, useEffect, useRef, useState } from "react";
import {
    GoogleMap,
    Marker,
    Autocomplete,
    useJsApiLoader,
} from "@react-google-maps/api";
import { CircleCheck, Loader2, MapPin, Search, TriangleAlert } from "lucide-react";

// ต้องตรงกับชื่อ key ที่ตั้งใน .env (Vite ต้องขึ้นต้นด้วย VITE_)
const GOOGLE_MAPS_API_KEY = import.meta.env.VITE_GOOGLE_MAPS_API_KEY as string;

// libraries ต้องประกาศเป็น array นอก component ไม่งั้น useJsApiLoader จะ re-load ทุก render
const LIBRARIES: ("places")[] = ["places"];

const mapContainerStyle = {
    width: "100%",
    height: "320px",
};

// default center: กรุงเทพมหานคร (กรณียังไม่เคยปักหมุดมาก่อน)
const DEFAULT_CENTER = { lat: 13.7563, lng: 100.5018 };

interface LocationPinPickerProps {
    initialLat?: number | null;
    initialLng?: number | null;
    /** เรียกทุกครั้งที่ผู้ใช้กด "ยืนยันปักหมุด" เท่านั้น ไม่เรียกตอนแค่ลากเฉยๆ */
    onConfirm: (lat: number, lng: number, address: string | null) => void;
}

export default function LocationPinPicker({
    initialLat,
    initialLng,
    onConfirm,
}: LocationPinPickerProps) {
    const { isLoaded, loadError } = useJsApiLoader({
        googleMapsApiKey: GOOGLE_MAPS_API_KEY,
        libraries: LIBRARIES,
    });

    const [markerPos, setMarkerPos] = useState<{ lat: number; lng: number }>(
        initialLat && initialLng
            ? { lat: initialLat, lng: initialLng }
            : DEFAULT_CENTER
    );
    const [pendingAddress, setPendingAddress] = useState<string | null>(null);
    const [confirmed, setConfirmed] = useState(false);

    const mapRef = useRef<google.maps.Map | null>(null);
    const autocompleteRef = useRef<google.maps.places.Autocomplete | null>(null);

    // ✅ เพิ่มใหม่: แก้บั๊กหมุดค้างที่ตำแหน่ง default ตอน edit mode
    // useState ด้านบนคำนวณค่าเริ่มต้นแค่ตอน mount ครั้งเดียว แต่ initialLat/initialLng
    // ใน edit mode มาจาก fetch แบบ async ใน createTrip.tsx (setStartLat/setStartLng เกิด
    // "หลัง" LocationPinPicker mount ไปแล้ว) พอ prop เปลี่ยนทีหลัง useState เดิมไม่รู้ด้วย
    // เลยต้องมี effect นี้คอย sync ทุกครั้งที่ initialLat/initialLng เปลี่ยนจริง
    // (เช่น จาก null -> ค่าจริงที่โหลดมาจาก API)
    useEffect(() => {
        if (initialLat == null || initialLng == null) return;

        const pos = { lat: initialLat, lng: initialLng };
        setMarkerPos(pos);
        setConfirmed(true); // ค่านี้มาจากทริปที่บันทึกไว้แล้ว ถือว่ายืนยันอยู่แล้ว
        mapRef.current?.panTo(pos);
        mapRef.current?.setZoom(16);
    }, [initialLat, initialLng]);

    const onMapLoad = useCallback((map: google.maps.Map) => {
        mapRef.current = map;
    }, []);

    const onAutocompleteLoad = useCallback(
        (autocomplete: google.maps.places.Autocomplete) => {
            autocompleteRef.current = autocomplete;
        },
        []
    );

    const handlePlaceChanged = () => {
        const place = autocompleteRef.current?.getPlace();
        if (!place || !place.geometry || !place.geometry.location) return;

        const lat = place.geometry.location.lat();
        const lng = place.geometry.location.lng();

        setMarkerPos({ lat, lng });
        setPendingAddress(place.formatted_address || place.name || null);
        setConfirmed(false); // ค้นหาใหม่ = ต้องกดยืนยันใหม่เสมอ

        mapRef.current?.panTo({ lat, lng });
        mapRef.current?.setZoom(16);
    };

    const handleMarkerDragEnd = (e: google.maps.MapMouseEvent) => {
        if (!e.latLng) return;
        const lat = e.latLng.lat();
        const lng = e.latLng.lng();
        setMarkerPos({ lat, lng });
        setPendingAddress(null); // ลากเองแล้ว ไม่รู้ที่อยู่ชัวร์ ให้ reverse geocode คร่าวๆ ทีหลังได้ถ้าต้องการ
        setConfirmed(false); // ลากใหม่ = ต้องกดยืนยันใหม่เสมอ
    };

    const handleConfirm = () => {
        setConfirmed(true);
        onConfirm(markerPos.lat, markerPos.lng, pendingAddress);
    };

    if (loadError) {
        return (
            <p
                role="alert"
                className="flex items-start gap-2 text-sm rounded-xl px-4 py-3 bg-white border text-[color:var(--danger)] border-[color:var(--danger)]"
            >
                <TriangleAlert size={18} strokeWidth={1.75} className="shrink-0 mt-0.5" />
                <span>โหลดแผนที่ไม่สำเร็จ กรุณาตรวจสอบ VITE_GOOGLE_MAPS_API_KEY ใน .env</span>
            </p>
        );
    }

    if (!isLoaded) {
        return (
            <div className="flex items-center justify-center gap-2 h-80 rounded-xl border border-[color:var(--line)] bg-[color:var(--sky-soft)] text-sm text-[color:var(--deep)]">
                <Loader2 size={20} strokeWidth={1.75} className="animate-spin" />
                กำลังโหลดแผนที่...
            </div>
        );
    }

    return (
        <div className="flex flex-col gap-3">
            <div className="relative">
                <Search
                    size={20}
                    strokeWidth={1.75}
                    className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 z-10 text-[color:var(--sky)]"
                />
                <Autocomplete
                    onLoad={onAutocompleteLoad}
                    onPlaceChanged={handlePlaceChanged}
                >
                    <input
                        type="text"
                        aria-label="ค้นหาจุดเริ่มต้น"
                        placeholder="ค้นหาโรงแรมหรือสถานที่ เช่น ชื่อโรงแรม"
                        className="w-full min-h-12 pl-12 pr-4 py-3 rounded-xl border border-[color:var(--line)] bg-white text-[color:var(--text)] placeholder:text-[color:var(--muted)] placeholder:opacity-60 focus:outline-none focus:border-[color:var(--navy)] focus:ring-4 focus:ring-[color:var(--line)] transition-all duration-200 font-sarabun"
                    />
                </Autocomplete>
            </div>

            <div className="overflow-hidden rounded-xl border border-[color:var(--line)]">
                <GoogleMap
                    mapContainerStyle={mapContainerStyle}
                    center={markerPos}
                    zoom={initialLat && initialLng ? 16 : 11}
                    onLoad={onMapLoad}
                    options={{
                        streetViewControl: false,
                        mapTypeControl: false,
                        fullscreenControl: false,
                    }}
                >
                    <Marker
                        position={markerPos}
                        draggable
                        onDragEnd={handleMarkerDragEnd}
                    />
                </GoogleMap>
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                <p
                    className={`flex items-start gap-2 text-sm ${
                        confirmed
                            ? "text-[color:var(--success)] font-medium"
                            : "text-[color:var(--muted)]"
                    }`}
                >
                    {confirmed ? (
                        <CircleCheck size={18} strokeWidth={1.75} className="shrink-0 mt-0.5" />
                    ) : (
                        <MapPin size={18} strokeWidth={1.75} className="shrink-0 mt-0.5" />
                    )}
                    <span>
                        {confirmed
                            ? `ยืนยันจุดเริ่มต้นแล้ว (${markerPos.lat.toFixed(5)}, ${markerPos.lng.toFixed(5)})`
                            : "ลากหมุดหรือค้นหาสถานที่ แล้วกดยืนยันเพื่อบันทึกจุดเริ่มต้น"}
                    </span>
                </p>

                <button
                    type="button"
                    onClick={handleConfirm}
                    className={`font-prompt font-medium shrink-0 min-h-12 px-6 flex items-center justify-center gap-2 rounded-xl text-white active:scale-[0.98] transition-all duration-200 ${
                        confirmed
                            ? "bg-[color:var(--success)]"
                            : "bg-[color:var(--navy)] hover:bg-[color:var(--navy-dark)]"
                    }`}
                >
                    {confirmed ? (
                        <>
                            <CircleCheck size={20} strokeWidth={1.75} />
                            ยืนยันแล้ว
                        </>
                    ) : (
                        <>
                            <MapPin size={20} strokeWidth={1.75} />
                            ยืนยันปักหมุด
                        </>
                    )}
                </button>
            </div>
        </div>
    );
}